/*
Garrett Fellenz
CIS Course Project Heros Journey
5-24-24
*/

using System.Reflection;
using System.Reflection.Metadata.Ecma335;

public class Heros : Hero
{
   
public string Assasin{get; set;}
public string Theif{get; set;}
public string Knight{get; set;}
public string Mage{get; set;}

public Heros(string name, string heroType, string weapon,string assasin, string theif, string knight, string mage)
:base(name,heroType, weapon)
{
    Assasin = assasin;
    Theif = theif;
    Knight = knight;
    Mage = mage;

  int HeroType = 4; 
switch(HeroType)
{
  case 1:
  Console.WriteLine("Assassin");
  break;
  case 2: 
  Console.WriteLine("Theif");
  break;
  case 3: 
  Console.WriteLine("Knight");
  break;
  case 4:
  Console.WriteLine("Mage");
  break;
 
}
int Weapon = 4;
switch(Weapon)
{
  case 5: 
  Console.WriteLine("hidden blade");
  break;
  case 6:
  Console.WriteLine("Bow & Arrow");
  break;
  case 7:
  Console.WriteLine("Long Sword");
  break;
  case 8:
  Console.WriteLine("Fire Ball");
  break;
}
}


  public override string ToString()
   {
    return "Name:" + Name + "HeroType:"+HeroType+ "Weapon:"+ Weapon;
   }
   
}

