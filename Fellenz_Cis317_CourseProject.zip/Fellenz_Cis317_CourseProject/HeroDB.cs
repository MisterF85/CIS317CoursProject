/*
Garrett Fellenz
6/1/24
CIS CIS317 Database for course project
*/
using System.Data.Entity.Migrations.Model;
using System.Data.SQLite;
using System.Runtime.InteropServices;
public class HeroDb
{
    public static void CreateTable(SQLiteConnection conn)
    {
        // SQL statement for creating a new table
        string sql =
        "CREATE TABLE IF NOT EXISTS Hero (\n"
        + " ID integer PRIMARY KEY\n"
        + " ,Name varchar(20)\n"
        + " ,HeroType int(4) not null\n"
        + " ,Weapon int(4) not null);";
       
        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }
    public static void AddHero(SQLiteConnection conn, Hero p)
      {
        string sql = string.Format(
        "INSERT INTO Hero(Name, HeroType, Weapon) "
        + "VALUES('{0}','{1}',{2})",
        p.Name, p.HeroType, p.Weapon);
        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }
     public static void UpdateHero(SQLiteConnection conn, Hero p)
    {
        string sql = string.Format(
        "UPDATE Hero SET Name='{0}', HeroType='{1}', Weapon={2}"
        , p.Name, p.HeroType, p.Weapon);
        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }
     public static void DeleteHero(SQLiteConnection conn, string name)
    {
        string sql = string.Format("DELETE from Hero WHERE Name = {0}", name);
        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }
    public static List<Heros> GetAllHeros(SQLiteConnection conn)
    {
        List<Heros> hero = new List<Heros>();
        string sql = "SELECT * FROM Heros";
        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        SQLiteDataReader rdr = cmd.ExecuteReader();
        while (rdr.Read())
        {
            hero.Add(new Heros(
            rdr.GetString(0),
            rdr.GetString(1),
            rdr.GetString(2),
            rdr.GetString(3),
            rdr.GetString(5),
            rdr.GetString(6),
            rdr.GetString(7)
             ));
        }
        return hero;
    }
     public static Hero GetHero(SQLiteConnection conn, string name)
    {
        string sql = string.Format("SELECT * FROM Hero WHERE Name = {0}", name);
        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        SQLiteDataReader rdr = cmd.ExecuteReader();
        if (rdr.Read())
        {
            return new Hero(
            rdr.GetString(0),
            rdr.GetString(1),
            rdr.GetString(2)
            );
        }
        else
        {
            return new Hero(string.Empty, string.Empty, string.Empty);
        }
    }
}
    