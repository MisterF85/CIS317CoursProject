/*
Garrett Fellenz
CIS Course Project Heros Journey
5-24-24
*/

using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;

public class Hero : IJorney
{
    public string Name{get; set;}
    public string HeroType{get; set;}
    public string Weapon{get; set;}

 public Hero(string name, string heroType, string weapon) 
 {

    Name = name;
    HeroType = heroType;
    Weapon = weapon;

   
 }
   
    public void Move(string Start, string End)
    {
        throw new NotImplementedException();
    }
}