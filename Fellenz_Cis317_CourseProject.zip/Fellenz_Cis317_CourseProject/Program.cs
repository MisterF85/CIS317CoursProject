﻿/*
Garrett Fellenz
CIS Course Project Heros Journey
5-24-24
*/

using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;

public class HerosJourney
{
    static void Main(string[] args)
    {
        Console.WriteLine("Garrett Fellenz Course Project, A Heros Journey");

         Console.WriteLine("Enter your Heros Name:\n");
         Console.ReadLine();

         Console.WriteLine("Choose your Hero 1 for Assassin:\n{0} 2 for Theif:\n{1} 3 for Knight:\n{2} 4 for Mage\n{3}");
         Console.ReadLine();
         Console.WriteLine("Choose your Weapon:\n{0} 1 For Hidden Blade:\n 2 For Bow and Arrow:\n{1} 3 For Long Sword\n{2} 4 For FireBall\n{3}");
         Console.ReadKey();

         
    }
    public override string ToString()
    {
        return "Name" +  "HeroType"+  "Weapon";
    }
}
