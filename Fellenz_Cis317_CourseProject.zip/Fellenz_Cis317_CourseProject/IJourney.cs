/*
Garrett Fellenz
CIS Course Project Heros Journey
5-24-24
*/

public interface IJorney
{
    public string Name{get;}
    public string HeroType{get;}
    public string Weapon{get;}
    void Move(string Start, string End);
   // List<HerosJourney> = new List<HerosJourney>

}